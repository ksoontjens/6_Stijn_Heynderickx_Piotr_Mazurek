package eersteprog;

public class EersteProg {

    public static void main(String[] args) {
        System.out.println(~10);
        // 10 wordt 11 omdat de tekenbit wordt behouden (MSB)
    }

}
