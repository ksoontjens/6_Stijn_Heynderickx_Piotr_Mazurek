package fortowhile;

public class EersteProg {

    public static void main(String[] args) {
        int j = 55;
        for(int i=55; i > 34; i--) {
            System.out.println(i);
        }
       
        while(j > 34) {
            System.out.println(j);
            j--;
        }
    }

}
