package oef1;

public class Main {

    public static void main(String[] args) {
        Werknemer w1 = new Werknemer("Johan", "Poos", 1, 1800);
        Werknemer w2 = new Werknemer("Karel", "Krink", 1, 1650);
        Werknemer w3 = new Werknemer("Peter", "Pan", 1, 1700);
        Werknemer w4 = new Werknemer("Mieke", "Loos", 1, 1900);
    }

}
