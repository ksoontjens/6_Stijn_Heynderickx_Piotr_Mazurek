package oef4;

public class Main {

    public static void main(String[] args) {
        PartTimeWerknemer p1 = new PartTimeWerknemer("Hendrik", "Winckelmans", 1, 1800, 10);
        PartTimeWerknemer p2 = new PartTimeWerknemer("Petra", "Dejonghe", 3, 700, 20);
        p1.salarisVerhogen(10);
        System.out.println(p1.getSalaris());
    }

}
