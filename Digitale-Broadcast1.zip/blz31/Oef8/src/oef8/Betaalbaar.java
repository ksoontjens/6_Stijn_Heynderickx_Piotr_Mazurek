package oef8;

public interface Betaalbaar {
    public abstract void betaal();
}
