package oef8;

public class Main {

    public static void main(String[] args) {
        StudentWerknemer sw1 = new StudentWerknemer("Hendrik", "Winckelmans", 1, 1800, 20);
        
        System.out.println(sw1.getRSZ());       
    }

}
