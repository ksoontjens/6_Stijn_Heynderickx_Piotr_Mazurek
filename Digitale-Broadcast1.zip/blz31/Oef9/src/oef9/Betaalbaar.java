package oef9;

public interface Betaalbaar {
    public abstract void betaal();
}
