package oef6;

public class Main {

    public static void main(String[] args) {
        Werknemer w1 = new Werknemer("Hendrik", "Winckelmans", 1, 1800);
        PartTimeWerknemer p1 = new PartTimeWerknemer("Petra", "Dejonghe", 3, 700, 20);
        
        w1.setRSZ(20);
        p1.setRSZ(10);
        System.out.println(w1.getRSZ());
        System.out.println(p1.getRSZ());
    }

}
