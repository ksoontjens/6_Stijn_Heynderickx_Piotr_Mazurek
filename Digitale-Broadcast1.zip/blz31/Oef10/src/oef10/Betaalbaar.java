package oef10;

public interface Betaalbaar {
    public abstract void betaal();
}
