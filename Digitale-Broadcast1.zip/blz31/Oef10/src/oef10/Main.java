package oef10;

public class Main {

    public static void main(String[] args) {
        Faktuur f1 = new Faktuur(13999, 12000);
        
        f1.betaal();
    }

}
