package pagina19;

public class Oef6 {
    public void zoekGrootste() {
        int a[] = {12,34,56,78,123,234,99,88};
        int i, grootste = 0;
        for(i = 0; i < a.length; i++) {
            if(a[i] > grootste) {
                grootste = a[i];
            }
        }
        System.out.println("Het grootste getal is " + grootste);
    }
}
