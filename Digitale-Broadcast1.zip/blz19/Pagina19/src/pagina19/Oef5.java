package pagina19;

public class Oef5 {
    public void priemGetallen() {
        int i, j;
        boolean priem;
        
        for(i = 3; i < 100; i++) {
            priem = false;
            for(j = 1; j < i - 1; j++) {
                if(i % j == 0) {
                    priem = false;
                } else {
                    priem = true;
                }
            }
            if(priem) {
                System.out.println(i + " is een priemgetal.");
            }
        }
    }
}
