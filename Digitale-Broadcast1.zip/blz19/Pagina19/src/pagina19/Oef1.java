package pagina19;

public class Oef1 {
    
    public void printTafels() {
        for(int i =1 ; i < 10; i++) {
            for(int j = 1; j < 11; j++) {
                System.out.println(i + "x" + j + "=" + (i * j));
            }
        }
    }
}
