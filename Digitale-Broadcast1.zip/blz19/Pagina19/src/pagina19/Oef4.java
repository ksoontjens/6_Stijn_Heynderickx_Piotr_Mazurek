package pagina19;

public class Oef4 {
    private int getal = 4302;
    
    public void negate() {
        int resultaat = ~getal;
        resultaat += 1;
        System.out.println(getal + " wordt " + resultaat);        
    }
}
