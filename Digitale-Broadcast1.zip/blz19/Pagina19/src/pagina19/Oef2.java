package pagina19;

public class Oef2 {
    
    public void printMaand() {
        int i, j;
        for(i = 1; i < 5; i++) {
            for(j = 1; j < 8; j++) {
                switch(j) {
                    case 1 : System.out.println("zondag " + i*j + " februari");
                    case 2 : System.out.println("maandag " + i*j + " februari");
                    case 3 : System.out.println("dinsdag " + i*j + " februari");
                    case 4 : System.out.println("woensdag " + i*j + " februari");
                    case 5 : System.out.println("donderdag " + i*j + " februari");
                    case 6 : System.out.println("vrijdag " + i*j + " februari");
                    case 7 : System.out.println("zaterdag " + i*j + " februari");
                }
            }
        }
    }
}