package eersteprog;

/**
 * De klasse EersteProg is een Java applicatie.
 * @author Blommaert William
 * @version 1.0
 */
public class EersteProg {
/**
 * Deze functie zal het programma starten.
 * @param args Dit is een array van String elementen waarmee parameters kunnen meegegeven worden via commandline
 */
    public static void main(String[] args) {
        drukAf(100);
    }
/**
 * Deze functie genereert output op basis van de parameter.
 * @param aantal Dit geeft aan hoeveel afdrukken er zullen gemaakt worden.
 */    
    private static void drukAf(int aantal) {
        int i;
        
        for(i = 0; i < aantal; i++) {
            System.out.println(i);
        }
    
    }
    
    
}
