package hellotvxlet;

import javax.tv.xlet.*;


public class HelloTVXlet implements Xlet {

  
    public HelloTVXlet() {
        
    }

    public void initXlet(XletContext context) {
      
     
    }

    public void startXlet() {
    
    }

    public void pauseXlet() {
     
    }

    public void destroyXlet(boolean unconditional) {
     
    }
}
