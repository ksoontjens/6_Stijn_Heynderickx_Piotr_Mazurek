/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

import org.havi.ui.*;
import java.awt.*;

/**
 *
 * @author student
 */
public class MijnComponent extends HComponent{
    int br, ho;
    Image schipimg;
    Image sterrenimg;
    int x;
    int y;
    int scrollY = 0;
    public MijnComponent(int posX, int posY, int width, int height){
        this.setBounds(posX,posY,width,height);
        br=width;
        ho=height;
        x= posX;
        y= posY;
        schipimg=this.getToolkit().getImage("spaceship.png");
        sterrenimg=this.getToolkit().getImage("sterren.png");
        MediaTracker mt = new MediaTracker(this);
        mt.addImage(schipimg, 0);
        mt.addImage(sterrenimg, 1);
        
        try{
            mt.waitForAll();
        }
        catch(InterruptedException ex){
            ex.printStackTrace();
        }
    }
    public void moveUp(){
        y-=5;if(y<0)y=0;
        this.repaint();
    }
    public void moveDown(){
        y+=5;if(y>531)y=531;
        this.repaint();
    }
    public void moveLeft(){
        x-=5; if(x<0) x = 0;
        this.repaint();
    }
    public void moveRight(){
        x+=5;if(x>672) x = 672;
        this.repaint();
    }
    public void paint(Graphics g){
        g.drawImage(sterrenimg, 0, scrollY, null);
        g.drawImage(sterrenimg, 0, scrollY-570, null);
        g.drawImage(schipimg, x, y, null);
    }
    public void scroll(){
        scrollY+=5; if (scrollY > 570)scrollY = 0;
        this.repaint();
    }
}
