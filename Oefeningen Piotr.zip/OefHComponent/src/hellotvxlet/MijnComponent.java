/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

import java.awt.Color;
import java.awt.Graphics;
import org.dvb.ui.DVBColor;
import org.havi.ui.HComponent;

/**
 *
 * @author student
 */
public class MijnComponent extends HComponent{
    int br, ho;
    public MijnComponent(int posX, int posY, int width, int height){
        this.setBounds(posX,posY,width,height);
        br= width;
        ho=height;
    }
    public void paint(Graphics g){
        g.setColor(new DVBColor(0,0,255,179));
        g.fillRoundRect(0, 0, br-5, ho-5, 50, 50);
        g.setColor(new DVBColor(254,255,0,179));
        g.drawString("Hallo", 75, 100); 
        g.setColor(new DVBColor(0,0,0,50));
        g.fillRoundRect(5, 5, br-5, ho-5, 50, 50);
    }
}
