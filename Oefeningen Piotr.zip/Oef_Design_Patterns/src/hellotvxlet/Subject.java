/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

import java.util.ArrayList;
import java.util.TimerTask;

/**
 *
 * @author student
 */
public class Subject extends TimerTask implements SubjectInterface {
    int tijd = 0;
    ArrayList obList = new ArrayList();
    public void run() {
        tijd++;
        for(int i = 0; i<obList.size(); i++){
            ((ObserverInterface) obList.get(i)).update(tijd);
        }
        
    }

    public void register(ObserverInterface ob) {
        obList.add(ob);
    }

    public void unregister(ObserverInterface ob) {
        obList.remove(ob);
    }

}
