package hellotvxlet;

import java.util.Timer;
import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;
import javax.tv.xlet.XletStateChangeException;
import org.havi.ui.*;




public class HelloTVXlet implements Xlet {
    static HScene scene = null;
    static Subject publisher  = null;
    
    public static HScene getScene(){
        return scene;
    }
    public static Subject getPublisher(){
        return publisher;
    }
    
    public void destroyXlet(boolean arg0) throws XletStateChangeException {
    }

    public void initXlet(XletContext arg0) throws XletStateChangeException {
        scene = HSceneFactory.getInstance().getDefaultHScene();
        
        publisher = new Subject();
        Timer tim1 = new Timer();
        tim1.scheduleAtFixedRate(publisher, 0, 10);
        for(int x = 0; x < 5; x++){
            for(int y = 0; y < 2; y++){
                Enemy e = new Enemy(x*100, y*100);
                scene.add(e);
                publisher.register(e);
            }
        }
        scene.validate();
        scene.setVisible(true);
    }

    public void pauseXlet() {
    }

    public void startXlet() throws XletStateChangeException {
    }
    
    
}
   
    

