/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

import java.awt.Image;
import java.awt.MediaTracker;
import java.util.Random;
import org.havi.ui.*;

/**
 *
 * @author student
 */
public class Enemy extends Sprite{
    Image mijnImage;
    int richting = 1;
    Random r;
    static int aantalEnemies = 0;
    public Enemy(int x, int y){
        super(x, y);
        mijnImage = this.getToolkit().getImage("spaceship.png");
        MediaTracker mt = new MediaTracker(this);
        mt.addImage(mijnImage, 1);
        try {
            mt.waitForAll();
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        this.setGraphicContent(mijnImage, HVisible.NORMAL_STATE);
        this.setSize(mijnImage.getWidth(this), mijnImage.getHeight(this));
        aantalEnemies++;
        r = new Random();
        r.setSeed(aantalEnemies);
    }
    
    
    public void update(int tijd) {
        int x = this.getX();
        int y = this.getY();
        x = x + richting;
        if(x<=0){
            richting = 1;
        }
        if(x >= 720-mijnImage.getWidth(this)){
            richting = -1;
        }
        this.setLocation(x, y);
        
        if(r.nextInt(500) == 250)
        {
            EnemyRocket raket = new EnemyRocket(x, y+50);
            HelloTVXlet.getScene().add(raket);
            HelloTVXlet.getPublisher().register(raket);
        }
    }
    
}
