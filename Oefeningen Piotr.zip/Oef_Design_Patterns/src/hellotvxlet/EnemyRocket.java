/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

import java.awt.Image;
import java.awt.MediaTracker;
import org.havi.ui.*;

/**
 *
 * @author student
 */
public class EnemyRocket extends Sprite{
    Image mijnImage;
    int richting = 1;
    public EnemyRocket(int x, int y){
        super(x, y);
        mijnImage = this.getToolkit().getImage("rocketc.png");
        MediaTracker mt = new MediaTracker(this);
        mt.addImage(mijnImage, 1);
        try {
            mt.waitForAll();
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        this.setGraphicContent(mijnImage, HVisible.NORMAL_STATE);
        this.setSize(mijnImage.getWidth(this)/2, mijnImage.getHeight(this)/2);
    }
    
    
    public void update(int tijd) {
        int x = this.getX();
        int y = this.getY();
        y++;
        if(y > 576){
            HelloTVXlet.scene.remove(this);
            HelloTVXlet.publisher.unregister(this);
        }
        this.setLocation(x, y);
    }
    
}
