/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hellotvxlet;

/**
 *
 * @author student
 */
public interface SubjectInterface {
    
    public abstract void register(ObserverInterface ob);
    public abstract void unregister(ObserverInterface ob);
}
