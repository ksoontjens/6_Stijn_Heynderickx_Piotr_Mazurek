package hellotvxlet;

import java.io.IOException;
import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;
import javax.tv.xlet.XletStateChangeException;
import org.davic.resources.*;
import org.havi.ui.*;
import org.havi.ui.event.*;


import java.awt.event.KeyEvent;
import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;




public class HelloTVXlet implements Xlet, ResourceClient, HBackgroundImageListener, UserEventListener {
    
    HStillImageBackgroundConfiguration hsibc;
    HBackgroundDevice hBackgroundDev;
    HScene scene = HSceneFactory.getInstance().getDefaultHScene();
    String orderstring = "Orderlijst:";
    HStaticText statictext;
    HBackgroundImage bgImg1 = new HBackgroundImage("pizza1.m2v");
    HBackgroundImage bgImg2 = new HBackgroundImage("pizza2.m2v");
    HBackgroundImage bgImg3 = new HBackgroundImage("pizza3.m2v");
    HBackgroundImage bgImg4 = new HBackgroundImage("pizza4.m2v");
    int teller = 0;
    
    public void destroyXlet(boolean arg0) throws XletStateChangeException {
    }
    public void userEventReceived(UserEvent e){
        System.out.println(e.toString());
        if(e.getType() == KeyEvent.KEY_PRESSED){
                switch(e.getCode()){
                case HRcEvent.VK_RIGHT:
                    teller++;
                    if(teller > 4 ){
                        teller =4;}
                    break; 
                case HRcEvent.VK_LEFT:
                    teller--;
                    if(teller < 1 ){
                        teller = 1;}
                    break;  
                case HRcEvent.VK_ENTER:
                    switch(teller){
                        case 1:
                            orderstring += "\n Pepperoni";
                            break;
                        case 2:
                            orderstring += "\n Miauw";
                            break;
                        case 3:
                            orderstring += "\n Lekker";
                            break;
                        case 4:
                            orderstring += "\n Hawai";
                            break;
                    }
                    statictext.setTextContent(orderstring, HStaticText.NORMAL_STATE);
                    break;
                        
            }
        }
        if(teller == 1) try {
            hsibc.displayImage(bgImg1);
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (HPermissionDeniedException ex) {
            ex.printStackTrace();
        } catch (HConfigurationException ex) {
            ex.printStackTrace();
        }
        if(teller == 2) try {
            hsibc.displayImage(bgImg2);
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (HPermissionDeniedException ex) {
            ex.printStackTrace();
        } catch (HConfigurationException ex) {
            ex.printStackTrace();
        }
        if(teller == 3) try {
            hsibc.displayImage(bgImg3);
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (HPermissionDeniedException ex) {
            ex.printStackTrace();
        } catch (HConfigurationException ex) {
            ex.printStackTrace();
        }
        if(teller == 4) try {
            hsibc.displayImage(bgImg4);
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (HPermissionDeniedException ex) {
            ex.printStackTrace();
        } catch (HConfigurationException ex) {
            ex.printStackTrace();
        }
    }
    public void initXlet(XletContext arg0) throws XletStateChangeException {
        HScreen hscreen = HScreen.getDefaultHScreen();
        hBackgroundDev = hscreen.getDefaultHBackgroundDevice();
        hBackgroundDev.reserveDevice(this);
        HBackgroundConfigTemplate cfgTemplate = new HBackgroundConfigTemplate();
        cfgTemplate.setPreference(HBackgroundConfigTemplate.STILL_IMAGE, HBackgroundConfigTemplate.REQUIRED);
        hsibc = (HStillImageBackgroundConfiguration)hBackgroundDev.getBestConfiguration(cfgTemplate);
        try {
            if(hBackgroundDev.setBackgroundConfiguration(hsibc)){
                System.out.println("Config gelukt!");
            }
        
        } catch (SecurityException ex) {
            ex.printStackTrace();
        } catch (HPermissionDeniedException ex) {
            ex.printStackTrace();
        } catch (HConfigurationException ex) {
            ex.printStackTrace();
        }
        statictext = new HStaticText(orderstring, 300, 50,300,400);
        scene.add(statictext);
        scene.validate();
        scene.setVisible(true);
    }

    public void pauseXlet() {
    }

    public void startXlet() throws XletStateChangeException {
        EventManager manager = EventManager.getInstance();
        
        UserEventRepository repository = new UserEventRepository("Voorbeeld");
        repository.addAllArrowKeys();
        repository.addKey(HRcEvent.VK_ENTER);
        manager.addUserEventListener(this ,repository);
        bgImg1.load(this);
        bgImg2.load(this);
        bgImg3.load(this);
        bgImg4.load(this);
    }

    public boolean requestRelease(ResourceProxy arg0, Object arg1) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void release(ResourceProxy arg0) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void notifyRelease(ResourceProxy arg0) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void imageLoaded(HBackgroundImageEvent arg0) {
        try{
            hsibc.displayImage(bgImg1);
        }
        catch (Exception s){
            System.out.print(s.toString());
        }
    }

    public void imageLoadFailed(HBackgroundImageEvent arg0) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
   
    

